function [normal,cross_prod] = normal_rotated(solar_direct_unit,desired_reflected_ray_unit)


cross_prod= cross(solar_direct_unit, desired_reflected_ray_unit);




anglemirror = asin(norm(cross_prod));
if(dot(solar_direct_unit, desired_reflected_ray_unit)<0)
    anglemirror= pi-anglemirror;
end
M_mirror = rotmatgen(unit(cross_prod), anglemirror/2);
%Determine the normal vector
if anglemirror~= 0
    normal=M_mirror*solar_direct_unit';
else
    normal= solar_direct_unit;
end



end

