function [angle, M, solar_direct_unit,solar_altitude] = Sun_pos(ts,dec_rad,W_rad)


%Solar hour angle
w = 15*(ts-12);
% Solar orientation
solar_altitude = 180/pi*asin(sin(dec_rad)*sin(W_rad)+cos(dec_rad)*cos(W_rad)*cos(w*pi/180));
solar_altitude_rad = solar_altitude*pi/180;
solar_azimuth = 180/pi*atan2(cos(dec_rad)*sin(w*pi/180)/cos(solar_altitude_rad),(sin(solar_altitude_rad)*sin(W_rad)-sin(dec_rad))/cos(solar_altitude_rad)/cos(W_rad));
solar_azimuth_rad = solar_azimuth*pi/180;
% direction vector
if (solar_azimuth> 0)
    X = -1;
else
    X = 1;
end

Y = X/tan(solar_azimuth_rad); z =sqrt( X^2+Y^2); Z = tan(solar_altitude_rad)*z;
direct = [X, Y,Z]; solar_direct_unit = unit(direct);
rotate_axis = cross(solar_direct_unit, [X,Y,0]);
angle = pi/2 -solar_altitude_rad;
M= rotmatgen(unit(rotate_axis), angle);

end

