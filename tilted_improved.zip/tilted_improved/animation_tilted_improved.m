close all; clear; clc

%% Section 1 calcuated the tilt value
n=175;% Number of days from Jan. 1st
ts =12; ts = ts+0.00000001;
latitude= 51.3;  % latitude(degree)
Pos_receiver = [0,  0 , 5];
sizeof_heliostat =2;
[normal_mirror_atnoon,normal_heli_atnoon,cross_prod_mirror] = tilted_decide(n,ts,latitude,Pos_receiver,sizeof_heliostat);



%% Section 2 plot animation
% Solar position, parameter: Number of days from Jan. 1st, timespacing, irradiance
%Local apparent time
timespacing=0.8; number_timeslot = 24/ timespacing;
ray_density = 50;

%Declination Angle Calculation (cooper function)
dec = 23.45*sin(2*pi*(284+n)/365);
dec_rad= dec*pi/180;
W_rad = latitude*pi/180;
%% Heliostat  part, parameter:size of heliostat, length and width of mirror, position and radius of receiver, Irradiance
% Parameters of mirror and receiver
length_m = 0.34; width_m = 0.54;%maximum length and width
% Position and size of circular receiver
radius_rec = 0.3;
% receiver normal
normal_re = [0, 0, 1]; normal_re_unit =unit(normal_re);
[num_heliostats, pos_heliostat] = square_points(sizeof_heliostat);
%Number of mirrors per heliostat
num_mirrors_per_heli = 2;

%% Calculation part, parameter:Irradiance,  illuminated area
for i = 1:  number_timeslot +1
    %Local apparent time
    ts(i) =timespacing*(i-1)+0.0000001;
    % rotated angle, rotated matrix, solar ray direction and solar altitude
    [angle, M, solar_direct_unit,solar_altitude] = Sun_pos(ts(i),dec_rad,W_rad);

    if (solar_altitude < 0)
        fprintf('after sunset and before sunrise\n');
        effciency_reflected(i)=0;

    else
        %% determine normals of heliostats and draw
        % Irradiance
        irradiance =ray_density/2*(sizeof_heliostat);
        % illuminated area
        [num_flux, pos_flux] = square_points(irradiance);
        pos_flux = pos_flux*(sizeof_heliostat)/irradiance;
        for j=1:num_flux

            if angle~= 0
                pos_flux(j,:)=M*pos_flux(j,:)';
            else
                pos_flux(j,:)= pos_flux(j,:);
            end
        end
        %%%Determine the normal vector
        normal_heli= zeros(size( pos_heliostat));
        normal= zeros(num_heliostats* num_mirrors_per_heli  ,3);
        for j=1:num_heliostats
            %Desired reflectedrays
            desired_reflected_ray = Pos_receiver -  pos_heliostat(j,:);
            desired_reflected_ray_unit=unit(desired_reflected_ray);
            %Angle between incident rays and desired reflected rays
            [normal_heli(j,:),cross_prod_heli(j,:)]= ...
                normal_rotated(solar_direct_unit, desired_reflected_ray_unit);

            pos_mirror(num_mirrors_per_heli*j-1,:)=pos_heliostat(j,:)+0.25*unit(cross_prod_heli(j,:));
            pos_mirror(num_mirrors_per_heli*j,:)=pos_heliostat(j,:)-0.25*unit(cross_prod_heli(j,:));



            %find the angle and rotation matrix
            [angle2,M] =  full_rotated(normal_heli(j,:),-normal_heli_atnoon(j,:));

            %calculated rotated angle
            for jj=1:num_mirrors_per_heli

                if angle2~= 0
                    normal(2*(j-1)+jj,:)=M*normal_mirror_atnoon(2*(j-1)+jj,:)';
                    cross_prod_new(2*(j-1)+jj,:)=M*unit(cross_prod_mirror(2*(j-1)+jj,:))';
                else
                    normal(2*(j-1)+jj,:)= normal_mirror_atnoon(2*(j-1)+jj,:);
                    cross_prod_new(2*(j-1)+jj,:)=unit(cross_prod_mirror(2*(j-1)+jj,:));
                end

                direct_edge_unit(2*(j-1)+jj,:)= unit(cross(cross_prod_new(2*(j-1)+jj,:),normal(2*(j-1)+jj,:)));
                a = length_m/2;  b = width_m/2;
                P = [-a  a; -a a];
                Q =[-b -b; b b];

                X1 = pos_mirror(num_mirrors_per_heli*(j-1)+jj,1)+cross_prod_new(2*(j-1)+jj,1)*P+direct_edge_unit(2*(j-1)+jj,1)*Q; % Compute the corresponding cartesian coordinates
                Y1 = pos_mirror(num_mirrors_per_heli*(j-1)+jj,2)+cross_prod_new(2*(j-1)+jj,2)*P+direct_edge_unit(2*(j-1)+jj,2)*Q; %   using the two vectors in w
                Z1 = pos_mirror(num_mirrors_per_heli*(j-1)+jj,3)+cross_prod_new(2*(j-1)+jj,3)*P+direct_edge_unit(2*(j-1)+jj,3)*Q;
                surf(X1,Y1,Z1,0); hold on;

                normal_line(j, :) = pos_mirror(num_mirrors_per_heli*(j-1)+jj,:) + 2*normal(2*(j-1)+jj,:);
                plot3([pos_mirror(num_mirrors_per_heli*(j-1)+jj,1) normal_line(j,1)], [pos_mirror(num_mirrors_per_heli*(j-1)+jj,2) normal_line(j,2)],[pos_mirror(num_mirrors_per_heli*(j-1)+jj,3) normal_line(j,3)],'color', 'cyan');
            end
            plot3([pos_mirror(num_mirrors_per_heli*j-1,1) pos_mirror(num_mirrors_per_heli*j,1)],[pos_mirror(num_mirrors_per_heli*j-1,2) pos_mirror(num_mirrors_per_heli*j,2)],[pos_mirror(num_mirrors_per_heli*j-1,3) pos_mirror(num_mirrors_per_heli*j,3)],  'color', 'black');
        end
        %% reciever mirror
        theta2=(0:2*pi/100:2*pi)';
        a2=unit(cross(normal_re_unit ,[1 0 0]));
        if ~any(a2)
            a2=unit(cross(normal_re_unit ,[0 1 0]));
        end
        b2=unit(cross(normal_re_unit ,a2));
        x2=Pos_receiver(1)+radius_rec*a2(1)*cos(theta2)+radius_rec*b2(1)*sin(theta2);
        y2=Pos_receiver(2)+radius_rec*a2(2)*cos(theta2)+radius_rec*b2(2)*sin(theta2);
        z2=Pos_receiver(3)+radius_rec*a2(3)*cos(theta2)+radius_rec*b2(3)*sin(theta2);
        plot3(x2,y2,z2,'color','black','LineWidth',2);


        %% Reflected ray vector
        s0 = zeros(num_heliostats* num_mirrors_per_heli  ,1);
        intersection_point = zeros(size( pos_mirror));
        reflected_intersection_point =  zeros(size( pos_flux));
        num_existray = 0;
        for j = 1:num_flux
            flag = 0;
            for jj = 1: num_heliostats* num_mirrors_per_heli
                s0(jj)= dot((pos_mirror(jj,:)-pos_flux(j,:)),normal(jj, :))/dot(solar_direct_unit,normal(jj, :));
                intersection_point(jj,:)= pos_flux(j,:)+ s0(jj)*solar_direct_unit;
                if (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==0)
                    s0_eff = s0(jj);    flag = 1;   no_mirror = jj;
                elseif (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==1)&&(s0(jj)>s0_eff)
                    s0_eff = s0(jj);    no_mirror = jj;
                end
            end
            if flag
                a2 = -solar_direct_unit - 2*dot(-solar_direct_unit,normal(no_mirror, :))*normal(no_mirror, :);
                s0_ref= dot((Pos_receiver-intersection_point(no_mirror,:)),normal_re_unit)/dot(a2,normal_re_unit);
                reflected_intersection_point(j,:) = intersection_point(no_mirror,:)+s0_ref*a2;
                num_existray  = num_existray +1;
                %Plot ray
                start = intersection_point(no_mirror,:)+5*solar_direct_unit;
                plot3([start(1) intersection_point(no_mirror,1)],[start(2) intersection_point(no_mirror,2)],[start(3) intersection_point(no_mirror,3)],  'color', 'red');
                plot3([intersection_point(no_mirror,1) reflected_intersection_point(j,1)],[intersection_point(no_mirror,2) reflected_intersection_point(j,2)],[intersection_point(no_mirror,3) reflected_intersection_point(j,3)], 'color', 'blue');

            end
        end
        axis equal
        xlim([-2 2])
        ylim([-2 2])
        zlim([-2 5])
        % view(0,90);



        %% effciency calculation
        effciency_reflected(i)= 100*num_existray/ num_flux;
        %reset index
        for mm = 1: num_flux
            if (reflected_intersection_point(mm,3)~= 0)
                aperture (mm) = norm(reflected_intersection_point(mm,:)-Pos_receiver);
            end
        end
        Maximum_aper (i)= max(aperture);
        hold off;
        %legend('Mirror location', 'Receiver location');
    end
    drawnow;
end
plot(ts,effciency_reflected)
hold on
xlabel('Local time(h)');
ylabel('Efficiency(%)');
title('Reflected efficiency');
hold off

clearvars  -except      Maximum_aper  effciency_reflected  normal  pos_mirror effciency_reflected Maximum_aper solar_altitude_rad ts Ns