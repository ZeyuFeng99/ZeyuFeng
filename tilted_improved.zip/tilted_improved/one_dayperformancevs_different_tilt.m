close all; clear; clc

timespacing=2; number_timeslot1 = 16/ timespacing;
% Plot reference time of tilt from 4-20
ts = 4:timespacing:20;
for i = 1:number_timeslot1+1
    %% Section 1 calcuated the tilt value
    n1=175;% Number of days from Jan. 1st

    latitude= 51.3;  % latitude(degree)
    Pos_receiver = [0,  0 , 5];
    sizeof_heliostat =2;
    [normal_mirror_atnoon,normal_heli_atnoon,cross_prod_mirror] = tilted_decide(n1, ts(i)+0.00000001 ,latitude,Pos_receiver,sizeof_heliostat);


    %% Section 2 receiver distrubution
    n2 = 175;
    timespacing1=2; number_timeslot = 24/ timespacing1;
    % Solar position, parameter: Number of days from Jan. 1st, Local apparent time, irradiance
    %Local apparent time
    for ii = 1:number_timeslot+1
        t(ii) =timespacing1*(ii-1);
        ray_density = 120;

        %Declination Angle Calculation (cooper function)
        dec = 23.45*sin(2*pi*(284+n2)/365);
        dec_rad= dec*pi/180;
        W_rad = latitude*pi/180;
        %% Heliostat  part, parameter:size of heliostat, length and width of mirror, position and radius of receiver, Irradiance
        % Parameters of mirror and receiver
        length_m = 0.34; width_m = 0.54;%maximum length and width
        % Size of circular receiver
        radius_rec = 0.3;
        % receiver normal
        normal_re = [0, 0, 1]; normal_re_unit =unit(normal_re);
        [num_heliostats, pos_heliostat] = square_points(sizeof_heliostat);
        %Number of mirrors per heliostat
        num_mirrors_per_heli = 2;

        %% Calculation part, parameter:Irradiance,  illuminated area
        % rotated angle, rotated matrix, solar ray direction and solar altitude
        [angle, M, solar_direct_unit,solar_altitude] = Sun_pos(t(ii)+0.0000001,dec_rad,W_rad);

        if (solar_altitude < 0)
            fprintf('after sunset and before sunrise\n');
            effciency_reflected=0;
            effciency_received=0;
            counts(ii,:) =0;
            Max_aper(ii)=0;
            Re_power(ii)=0;
        else
            %% determine normals of heliostats and draw
            % Irradiance
            irradiance =ray_density/2*(sizeof_heliostat);
            % illuminated area
            [num_flux, pos_flux] = square_points(irradiance);
            pos_flux = pos_flux*(sizeof_heliostat)/irradiance;
            for j=1:num_flux
                if angle~= 0
                    pos_flux(j,:)=M*pos_flux(j,:)';
                else
                    pos_flux(j,:)= pos_flux(j,:);
                end
            end

            %%%Determine the normal vector
            normal_heli= zeros(size( pos_heliostat));
            normal= zeros(num_heliostats* num_mirrors_per_heli  ,3);
            for j=1:num_heliostats
                %Desired reflectedrays
                desired_reflected_ray = Pos_receiver -  pos_heliostat(j,:);
                desired_reflected_ray_unit=unit(desired_reflected_ray);
                %Angle between incident rays and desired reflected rays
                [normal_heli(j,:),cross_prod_heli(j,:)]= ...
                    normal_rotated(solar_direct_unit, desired_reflected_ray_unit);

                pos_mirror(num_mirrors_per_heli*j-1,:)=pos_heliostat(j,:)+0.25*unit(cross_prod_heli(j,:));
                pos_mirror(num_mirrors_per_heli*j,:)=pos_heliostat(j,:)-0.25*unit(cross_prod_heli(j,:));



                %find the angle and rotation matrix
                [angle2,M] =  full_rotated(normal_heli(j,:),-normal_heli_atnoon(j,:));

                %calculated rotated angle
                for jj=1:num_mirrors_per_heli

                    if angle2~= 0
                        normal(2*(j-1)+jj,:)=M*normal_mirror_atnoon(2*(j-1)+jj,:)';
                        cross_prod_new(2*(j-1)+jj,:)=M*unit(cross_prod_mirror(2*(j-1)+jj,:))';
                    else
                        normal(2*(j-1)+jj,:)= normal_mirror_atnoon(2*(j-1)+jj,:);
                        cross_prod_new(2*(j-1)+jj,:)=unit(cross_prod_mirror(2*(j-1)+jj,:));
                    end

                    direct_edge_unit(2*(j-1)+jj,:)= unit(cross(cross_prod_new(2*(j-1)+jj,:),normal(2*(j-1)+jj,:)));

                end
            end

            %% Reflected ray vector
            s0 = zeros(num_heliostats* num_mirrors_per_heli  ,1);
            intersection_point = zeros(size( pos_mirror));

            num_existray = 0;
            for j = 1:num_flux
                flag = 0;
                for jj = 1: num_heliostats* num_mirrors_per_heli
                    s0(jj)= dot((pos_mirror(jj,:)-pos_flux(j,:)),normal(jj, :))/dot(solar_direct_unit,normal(jj, :));
                    intersection_point(jj,:)= pos_flux(j,:)+ s0(jj)*solar_direct_unit;
                    if (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==0)
                        s0_eff = s0(jj);    flag = 1;   no_mirror = jj;
                    elseif (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==1)&&(s0(jj)>s0_eff)
                        s0_eff = s0(jj);    no_mirror = jj;
                    end
                end
                if flag
                    a2 = -solar_direct_unit - 2*dot(-solar_direct_unit,normal(no_mirror, :))*normal(no_mirror, :);
                    s0_ref= dot((Pos_receiver-intersection_point(no_mirror,:)),normal_re_unit)/dot(a2,normal_re_unit);
                    reflected_intersection_point(num_existray+1,:) = intersection_point(no_mirror,:)+s0_ref*a2;

                    distanceto_re(num_existray+1)  = norm(reflected_intersection_point(num_existray+1,:)-Pos_receiver);
                    num_existray  = num_existray +1;

                end
            end

            %     figure;
            %     plot(reflected_intersection_point(:, 1), reflected_intersection_point(:, 2), 'o','color','red'); hold on





            %% effciency calculation


            index = 0;


            for j=1: num_existray
                if distanceto_re(j)<=radius_rec
                    index=index+1;
                end
            end

                    % total 0.8kw/m^2
        Re_power(ii) = index*0.8/num_flux;
        end



        %     histogram(distanceto_re,max_radius);
        %     hold on
    end
    E_total (i)= polyarea(t,Re_power);
end
figure
plot(ts,E_total)
xlabel('Reference time of tilt');
ylabel('Received energy (kw·h/m^2)');

clearvars  -except  E_total counts t