function [inside] = whetherinsidesquare(intersection_point,pos_mirror,halflength_m,halfwidth_m,cross_prod_unit,direct_edge_unit)

p_length= dot(cross_prod_unit,pos_mirror-intersection_point);
p_width= dot(direct_edge_unit,pos_mirror-intersection_point);
if ((abs(p_length)<=halflength_m))&&((abs(p_width)<=halfwidth_m))
    inside = 1;
else
    inside=0;
end
end

