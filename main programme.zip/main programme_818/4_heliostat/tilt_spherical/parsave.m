
function parsave(fname, x,y,z,a)
save(fname, 'x', 'y','z','a')
end


