function [inside] = whetherinsidesphere(diamter_lateral,radius_sphere,normal, centre_mirror,intersection_point )    

if (dot((centre_mirror-intersection_point),normal)/radius_sphere) >=(sqrt(1-diamter_lateral^2/(4*radius_sphere^2)))
inside = 1;
else 
inside = 0;

end

