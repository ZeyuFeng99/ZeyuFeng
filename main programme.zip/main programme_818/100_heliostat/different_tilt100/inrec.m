function [In] = inrec(position, length2, width2, intersection)
        if (position(1)-length2<intersection(1))	&&	(intersection(1)<position(1)+length2)   &&  (position(2)-width2<intersection(2))    &&  (intersection(2)<position(2)+width2)
            In = 1;
        else
            In =0;
        end

end

