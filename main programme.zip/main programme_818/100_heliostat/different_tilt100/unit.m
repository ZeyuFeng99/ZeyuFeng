
function [y] =unit(x)

y = x/sqrt(x(1)^2+x(2)^2+x(3)^2 );

end


