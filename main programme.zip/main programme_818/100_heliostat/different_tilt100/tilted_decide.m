function [normal_mirror_atnoon,normal_heli_atnoon,cross_prod_mirror] = tilted_decide(n,ts,latitude,Pos_receiver,sizeof_heliostat)

dec = 23.45*sin(2*pi*(284+n)/365);
dec_rad= dec*pi/180;
W_rad = latitude*pi/180;

[num_heliostats, pos_heliostat] = square_points(sizeof_heliostat);
num_mirrors_per_heli = 2;
% rotated angle, rotated matrix, solar ray direction and solar altitude
 [angle, M, solar_direct_unit] = Sun_pos(ts,dec_rad,W_rad);
%%%Determine the normal vector
normal_heli= zeros(size( pos_heliostat));
normal= zeros(num_heliostats* num_mirrors_per_heli  ,3);
for j=1:num_heliostats
    %% helio
    %Desired reflectedrays
    desired_reflected_ray = Pos_receiver -  pos_heliostat(j,:);
    desired_reflected_ray_unit=unit(desired_reflected_ray);
    %Angle between incident rays and desired reflected rays
    [normal_heli_atnoon(j,:),cross_prod_heli(j,:)]= ...
        normal_rotated(solar_direct_unit, desired_reflected_ray_unit);

    %position of mirrors
    pos_mirror(num_mirrors_per_heli*j-1,:)=pos_heliostat(j,:)+0.25*unit(cross_prod_heli(j,:));
    pos_mirror(num_mirrors_per_heli*j,:)=pos_heliostat(j,:)-0.25*unit(cross_prod_heli(j,:));


    %% mirror
    for jj=1:num_mirrors_per_heli

        %Desired reflectedrays
        desired_reflected_ray_mirror=unit(Pos_receiver -  pos_mirror(2*(j-1)+jj,:)) ;

        %Angle between incident rays and desired reflected rays
         [normal_mirror_atnoon(2*(j-1)+jj,:),cross_prod_mirror(2*(j-1)+jj,:)]= ...
         normal_rotated(solar_direct_unit,  desired_reflected_ray_mirror );
    end
end
end

