close all; clear; clc
scale = 1:7;
angle =[1.52 1.49333 1.44 1.36 1.28 1.2 1.12];
plot(scale,angle,'-*','linewidth',3,'color','red');
hold on
cfun=fit(scale',angle','poly2');
scale = 1:0.25:9;
y=cfun(scale);

plot(scale,y,'linewidth',1,'color','blue');

ylabel('Tilt angle');
xlabel('distance');