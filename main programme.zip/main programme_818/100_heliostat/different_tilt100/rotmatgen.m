function M = rotmatgen(u, theta)

costheta = cos(theta);
sintheta = sin(theta);

M = [costheta+u(1)^2*(1-costheta) u(1)*u(2)*(1-costheta)-u(3)*sintheta u(1)*u(3)*(1-costheta)+u(2)*sintheta;
     u(2)*u(1)*(1-costheta)+u(3)*sintheta costheta + u(2)^2*(1-costheta) u(2)*u(3)*(1-costheta)-u(1)*sintheta;
     u(3)*u(1)*(1-costheta)-u(2)*sintheta u(3)*u(2)*(1-costheta)+u(1)*sintheta costheta+u(3)^2*(1-costheta)];

