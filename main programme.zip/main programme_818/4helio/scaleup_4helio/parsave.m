
function parsave(fname, x,y,z,m)
save(fname, 'x', 'y','z','m')
end

