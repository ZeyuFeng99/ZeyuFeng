close all; clear; clc

%% Solar position, parameter: Number of days from Jan. 1st, Local apparent time, latitude, ray_density
n=265; % Number of days from Jan. 1st
%Local apparent time
rotated_angle = 1.52; % degree

ts =12; ts = ts+0.00000001;
ray_density = 30;
 scale = 3;
 ray_scale = sqrt(2)*(scale+1)/2;
latitude= 51.3;  % latitude(degree)
%Declination Angle Calculation (cooper function)
dec = 23.45*sin(2*pi*(284+n)/365);
dec_rad= dec*pi/180;
W_rad = latitude*pi/180;
%% Heliostat  part, parameter:size of heliostat, length and width of mirror, position and radius of receiver, Irradiance
% Parameters of mirror and receiver
sizeof_heliostat =2;
length_m = 0.275; width_m = 0.6557;%maximum length and width
% Position and size of circular receiver
Pos_receiver = [0,  0 , 5];  radius_rec = 0.3;
% receiver normal
normal_re = [0, 0, 1]; normal_re_unit =unit(normal_re);
[num_heliostats, pos_heliostat] = square_points(sizeof_heliostat);

pos_heliostat=scale*pos_heliostat;
%Number of mirrors per heliostat
num_mirrors_per_heli = 2;

%% Calculation part, parameter:Irradiance,  illuminated area
% rotated angle, rotated matrix, solar ray direction and solar altitude
[angle, M, solar_direct_unit,solar_altitude] = Sun_pos(ts,dec_rad,W_rad);
% receivercolor=[[0 0 0];[0 0 0]; 	[1 0 1] ; 	[1 0 1]  ; 	[0 0 1] ;  	[0 0 1]; 	[0 1 0]  ; 	[0 1 0] ];
if (solar_altitude < 0)
    fprintf('after sunset and before sunrise\n');
    effciency_reflected=0;
    effciency_received=0;
else
    %% determine normals of heliostats and draw
    % Irradiance
    irradiance =ray_density/2*(sizeof_heliostat);
    % illuminated area
    [num_flux, pos_flux] = square_points(ray_scale*irradiance);
    pos_flux1 = pos_flux*(sizeof_heliostat)/irradiance;
    for j=1:num_flux

        if angle~= 0
            pos_flux(j,:)=M*pos_flux1(j,:)';
        else
            pos_flux(j,:)= pos_flux1(j,:);
        end
%         flux11= pos_flux(j,:)+10*solar_direct_unit;
%         flux22= pos_flux(j,:)-10*solar_direct_unit;
%         plot3([flux11(1) flux22(1)], [flux11(2) flux22(2)],[flux11(3) flux22(3)],'color', 'red');
%         hold on
    end

    %%%Determine the normal vector
    normal_heli= zeros(size( pos_heliostat));
    normal= zeros(num_heliostats* num_mirrors_per_heli  ,3);
    for j=1:num_heliostats
        %Desired reflectedrays
        desired_reflected_ray = Pos_receiver -  pos_heliostat(j,:);
        desired_reflected_ray_unit=unit(desired_reflected_ray);
        %Angle between incident rays and desired reflected rays
        [normal_heli(j,:),cross_prod(j,:)]= ...
            normal_rotated(solar_direct_unit, desired_reflected_ray_unit);

        pos_mirror(num_mirrors_per_heli*j-1,:)=pos_heliostat(j,:)+0.24*unit(cross_prod(j,:));
        pos_mirror(num_mirrors_per_heli*j,:)=pos_heliostat(j,:)-0.24*unit(cross_prod(j,:));


        cross_prod_unit_heli(j,:)= unit(cross_prod(j,:));
        direct_edge_unit_heli(j,:)= unit(cross(cross_prod(j,:),normal_heli(j,:))); % Find two orthonormal vectors which are orthogonal to v

        M_mirror(:,:,1) = rotmatgen(unit(direct_edge_unit_heli(j,:)), rotated_angle*pi/180);
        M_mirror(:,:,2) = rotmatgen(unit(direct_edge_unit_heli(j,:)), -rotated_angle*pi/180);

        %mirror
        for jj=1:num_mirrors_per_heli


            normal(2*(j-1)+jj,:) = M_mirror(:,:,jj)*normal_heli(j,:)';
            cross_prod_new(2*(j-1)+jj,:) = unit(cross(normal(2*(j-1)+jj,:) ,direct_edge_unit_heli(j,:)));

            a = length_m/2;  b = width_m/2;
            P = [-a  a; -a a];
            Q =[-b -b; b b];

%             color (1,1,:) = receivercolor(2*(j-1)+jj,:);
%             color (1,2,:) = receivercolor(2*(j-1)+jj,:);
%             color (2,1,:) = receivercolor(2*(j-1)+jj,:);
%             color (2,2,:) = receivercolor(2*(j-1)+jj,:);

            X1 = pos_mirror(num_mirrors_per_heli*(j-1)+jj,1)+ cross_prod_new(2*(j-1)+jj,1)*P+direct_edge_unit_heli(j,1)*Q; % Compute the corresponding cartesian coordinates
            Y1 = pos_mirror(num_mirrors_per_heli*(j-1)+jj,2)+ cross_prod_new(2*(j-1)+jj,2)*P+direct_edge_unit_heli(j,2)*Q; %   using the two vectors in w
            Z1 = pos_mirror(num_mirrors_per_heli*(j-1)+jj,3)+ cross_prod_new(2*(j-1)+jj,3)*P+direct_edge_unit_heli(j,3)*Q;
%             surf(X1,Y1,Z1,color); hold on;
            P1(num_mirrors_per_heli*(j-1)+jj,:) = [X1(1,1) X1(2,1) X1(2,2) X1(1,2) X1(1,1)];
            P2(num_mirrors_per_heli*(j-1)+jj,:) = [Y1(1,1) Y1(2,1) Y1(2,2) Y1(1,2) Y1(1,1)];
            surf(X1,Y1,Z1); hold on;
            direct_edge_unit(num_mirrors_per_heli*(j-1)+jj,:) = direct_edge_unit_heli(j, :);
            %             normal(num_mirrors_per_heli*(j-1)+jj,:) = normal_heli(j, :);
            normal_line= pos_mirror(num_mirrors_per_heli*(j-1)+jj,:) + 2*normal(2*(j-1)+jj,:);
            plot3([pos_mirror(num_mirrors_per_heli*(j-1)+jj,1) normal_line(1)], [pos_mirror(num_mirrors_per_heli*(j-1)+jj,2) normal_line(2)],[pos_mirror(num_mirrors_per_heli*(j-1)+jj,3) normal_line(3)],'color', 'cyan');
        end
        plot3([pos_mirror(num_mirrors_per_heli*j-1,1) pos_mirror(num_mirrors_per_heli*j,1)],[pos_mirror(num_mirrors_per_heli*j-1,2) pos_mirror(num_mirrors_per_heli*j,2)],[pos_mirror(num_mirrors_per_heli*j-1,3) pos_mirror(num_mirrors_per_heli*j,3)],  'color', 'black');
    end
    %% reciever mirror
    theta2=(0:2*pi/100:2*pi)';
    a2=unit(cross(normal_re_unit ,[1 0 0]));
    if ~any(a2)
        a2=unit(cross(normal_re_unit ,[0 1 0]));
    end
    b2=unit(cross(normal_re_unit ,a2));
    x2=Pos_receiver(1)+radius_rec*a2(1)*cos(theta2)+radius_rec*b2(1)*sin(theta2);
    y2=Pos_receiver(2)+radius_rec*a2(2)*cos(theta2)+radius_rec*b2(2)*sin(theta2);
    z2=Pos_receiver(3)+radius_rec*a2(3)*cos(theta2)+radius_rec*b2(3)*sin(theta2);
    plot3(x2,y2,z2,'color','black','LineWidth',2);



end

close all
%  plot(pos_flux(:, 1), pos_flux(:, 2), '.','color','red'); 
% hold on
% plot([0,solar_direct_unit(1)],[0,solar_direct_unit(2)]);
hold on
for i = 1:num_heliostats* num_mirrors_per_heli
     plot(P1(i,:),P2(i,:),'black','linewidth',0.5);
end
for j = 1:num_heliostats
 plot([pos_mirror(num_mirrors_per_heli*j-1,1) pos_mirror(num_mirrors_per_heli*j,1)],[pos_mirror(num_mirrors_per_heli*j-1,2) pos_mirror(num_mirrors_per_heli*j,2)], 'color', 'red');
end
circle1= radius_rec *cos(theta2);
circle2= radius_rec *sin(theta2);
  plot(circle1,circle2,'blue','linewidth',1);
xlabel('East-West');
ylabel('North-South');
%         xlim([-1 1])
%         ylim([-1 1])
title('Top view layout')
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
grid on
axis equal
hold off


clearvars  -except pos_flux  pos_heliostat