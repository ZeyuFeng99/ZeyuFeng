close all; clear; clc
start_angle =0.8; end_angle =1.2;
anglerange = end_angle-start_angle;
anglespacing=anglerange /15;
number_slot = anglerange/ anglespacing;
% Plot angle of tilt from 0-5
rotated_angle= start_angle:anglespacing:end_angle;
for scale = 1:7
    
    for i = 1:15+1
        name=sprintf('output%d.mat', 32*(scale-1)+i);
        load(name)
        for ii = 1:365+1
            
            E_total (i,ii)= sum(x(ii,:));
            
            
        end
        E_total_year(i,2*scale-1) =  sum(E_total(i,:) );
        
    end
    plot(rotated_angle,E_total_year(:,2*scale-1))
    hold on
end
% legend('1','1.5','2','2.5','3','3.5','4','4.5','5');
clearvars  -except E_total_year
