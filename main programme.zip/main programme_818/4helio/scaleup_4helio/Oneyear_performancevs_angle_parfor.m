close all; clear; clc
tic
for scale = 7:8
    start_angle =0.8; end_angle =1.2;
    anglerange = end_angle-start_angle;
    anglespacing=anglerange /15;
    number_slot = anglerange/ anglespacing;
    % Plot angle of tilt from 0-5
    rotated_angle= start_angle:anglespacing:end_angle;% degree
    rotated_angle = rotated_angle+0.00000001;% degree
    E_total_year = zeros(1,16);
    E_total_year1 = zeros(1,16);
    E_total_year2 = zeros(1,16);
    
    dayspacing=1; number_timeslot1 = floor(365/ dayspacing);
    % Plot reference time of tilt from 4-20
    n1 = 0:dayspacing:365;% Number of days from Jan. 1st
    
    timespacing=1; number_timeslot = 24/ timespacing;
    E_total  = zeros(1,number_timeslot1+1);
    E_total1  = zeros(1,number_timeslot1+1);
    E_total2  = zeros(1,number_timeslot1+1);
    parfor i = 1:number_slot+1
        Re_power1 = zeros(number_timeslot1+1,number_timeslot+1);
        Re_power2 = zeros(number_timeslot1+1,number_timeslot+1);
        Re_power3 = zeros(number_timeslot1+1,number_timeslot+1);
        for ii = 1:number_timeslot1+1
            %% Solar position, parameter: Number of days from Jan. 1st, Local apparent time, latitude, ray_density
            
            %Local apparent time
            
            ray_density = 80;
            
            
            ray_scale = (scale+1)/2;
            energy_scale=(ray_scale)^2;
            latitude= 51.3;  % latitude(degree)
            %Declination Angle Calculation (cooper function)
            dec = 23.45*sin(2*pi*(284+n1(ii))/365);
            dec_rad= dec*pi/180;
            W_rad = latitude*pi/180;
            %% Heliostat  part, parameter:size of heliostat, length and width of mirror, position and radius of receiver, Irradiance
            % Parameters of mirror and receiver
            sizeof_heliostat =2;
            length_m = 0.275; width_m = 0.6557;%maximum length and width
            % Position and size of circular receiver
            Pos_receiver = [0,  0 , 5];  radius_rec = 0.3; radius_rec1 = 0.35;  radius_rec2 = 0.4;
            % receiver normal
            normal_re = [0, 0, 1]; normal_re_unit =unit(normal_re);
            [num_heliostats, pos_heliostat] = square_points(sizeof_heliostat);
            %Number of mirrors per heliostat
            pos_heliostat=scale*pos_heliostat;
            num_mirrors_per_heli = 2;
            
            %% Calculation part, parameter:Irradiance,  illuminated area
            
            % Solar position, parameter: Number of days from Jan. 1st, Local apparent time, irradiance
            %Local apparent time
            t = zeros(1,number_timeslot+1);
            
            cross_prod = zeros(num_heliostats,3);
            pos_mirror =  zeros(2*num_heliostats,3);
            direct_edge_unit_heli = zeros(num_heliostats,3);
            cross_prod_new = zeros(2*num_heliostats,3);
            direct_edge_unit =  zeros(2*num_heliostats,3);
            for iii = 1:number_timeslot+1
                t(iii) =timespacing*(iii-1);
                % rotated angle, rotated matrix, solar ray direction and solar altitude
                [angle, M, solar_direct_unit,solar_altitude] = Sun_pos(t(iii)+0.000000001,dec_rad,W_rad);
                
                if (solar_altitude < 0)
                    fprintf('after sunset and before sunrise\n');
                    
                    
                else
                    %% determine normals of heliostats and draw
                    % Irradiance
                    irradiance =ray_density/2*(sizeof_heliostat);
                    % illuminated area
                    [num_flux, pos_flux] = square_points(ray_scale *irradiance);
                    pos_flux = pos_flux*(sizeof_heliostat)/irradiance;
                    for j=1:num_flux
                        
                        if angle~= 0
                            pos_flux(j,:)=M*pos_flux(j,:)';
                        else
                            pos_flux(j,:)= pos_flux(j,:);
                        end
                    end
                    
                    %%%Determine the normal vector
                    normal_heli= zeros(size( pos_heliostat));
                    normal= zeros(num_heliostats* num_mirrors_per_heli  ,3);
                    for j=1:num_heliostats
                        %Desired reflectedrays
                        desired_reflected_ray = Pos_receiver -  pos_heliostat(j,:);
                        desired_reflected_ray_unit=unit(desired_reflected_ray);
                        %Angle between incident rays and desired reflected rays
                        
                        [normal_heli(j,:),cross_prod(j,:)]= ...
                            normal_rotated(solar_direct_unit, desired_reflected_ray_unit);
                        
                        pos_mirror(num_mirrors_per_heli*j-1,:)=pos_heliostat(j,:)+0.24*unit(cross_prod(j,:));
                        pos_mirror(num_mirrors_per_heli*j,:)=pos_heliostat(j,:)-0.24*unit(cross_prod(j,:));
                        
                        % aviod solar direction is parallel to desired reflected ray
                        if (cross_prod(j,:)==0)
                            pre_direct_edg= load('direct_edge_unit_heli.mat');
                            direct_edge_unit_heli(j,:) = pre_direct_edg.x(j,:);
                        else
                            direct_edge_unit_heli(j,:)= unit(cross(cross_prod(j,:),normal_heli(j,:))); % Find two orthonormal vectors which are orthogonal to v
                        end
                        
                        
                        %mirror
                        for jj=1:num_mirrors_per_heli
                            
                            normal(2*(j-1)+jj,:) =  rotmatgen(unit(direct_edge_unit_heli(j,:)), (-1)^(jj+1)*rotated_angle(i)*pi/180)*normal_heli(j,:)';
                            cross_prod_new(2*(j-1)+jj,:) = unit(cross(normal(2*(j-1)+jj,:) ,direct_edge_unit_heli(j,:)));
                            
                            
                            
                            direct_edge_unit(num_mirrors_per_heli*(j-1)+jj,:) = direct_edge_unit_heli(j, :);
                            
                        end
                        
                    end
                    
                    
                    %% Reflected ray vector
                    s0 = zeros(num_heliostats* num_mirrors_per_heli  ,1);
                    intersection_point = zeros(size( pos_mirror));
                    
                    num_existray1 = 0;
                    num_existray2=0;
                    num_existray3=0;
                    for j = 1:num_flux
                        flag = 0;
                        for jj = 1: num_heliostats* num_mirrors_per_heli
                            s0(jj)= dot((pos_mirror(jj,:)-pos_flux(j,:)),normal(jj, :))/dot(solar_direct_unit,normal(jj, :));
                            intersection_point(jj,:)= pos_flux(j,:)+ s0(jj)*solar_direct_unit;
                            if (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==0)
                                s0_eff = s0(jj);    flag = 1;   no_mirror = jj;
                            elseif (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==1)&&(s0(jj)>s0_eff)
                                s0_eff = s0(jj);    no_mirror = jj;
                            end
                        end
                        if flag
                            a2 = -solar_direct_unit - 2*dot(-solar_direct_unit,normal(no_mirror, :))*normal(no_mirror, :);
                            s0_ref= dot((Pos_receiver-intersection_point(no_mirror,:)),normal_re_unit)/dot(a2,normal_re_unit);
                            if  norm((intersection_point(no_mirror,:)+s0_ref*a2)-Pos_receiver)<=radius_rec
                                num_existray1  = num_existray1 +1;
                            end
                            if  norm((intersection_point(no_mirror,:)+s0_ref*a2)-Pos_receiver)<=radius_rec1
                                num_existray2  = num_existray2 +1;
                            end
                            
                            if  norm((intersection_point(no_mirror,:)+s0_ref*a2)-Pos_receiver)<=radius_rec2
                                num_existray3  = num_existray3 +1;
                            end
                            
                        end
                    end
                    
                    %% effciency calculation
                    
                    % total 0.8kw/m^2
                    Re_power1(ii,iii) =  energy_scale*num_existray1  *0.8/num_flux;
                    Re_power2(ii,iii) =  energy_scale*num_existray2  *0.8/num_flux;
                    Re_power3(ii,iii) =  energy_scale*num_existray3  *0.8/num_flux;
                end
                
                
                
                %     histogram(distanceto_re,max_radius);
                %     hold on
            end
             
            parsave3(sprintf('direct_edge_unit_heli.mat'), direct_edge_unit);
            fprintf('%d\n',n1(ii));
        end
        parsave(sprintf('output%d.mat', 32*(scale-1)+i), Re_power1,Re_power2,Re_power3,  t );
        
    end
    
    
    
    toc
    for i = 1:number_slot+1
        name=sprintf('output%d.mat', 32*(scale-1)+i);
        load(name)
        for ii = 1:number_timeslot1+1
            
            E_total (i,ii)= sum(x(ii,:));

        end
        E_total_year(i) =  sum(E_total(i,:) );

    end
    plot(rotated_angle,E_total_year)
    hold on
end



xlabel('Tilt angle');
ylabel('Received energy (kw·h/m^2)');

% ylim([800 1000]);
title('One year performance');
clearvars  -except  E_total_year E_total E_total_year1 E_total1 E_total_year2 E_total2 x