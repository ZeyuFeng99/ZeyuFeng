
function parsave(fname, x,y,z)
save(fname, 'x', 'y','z')
end

