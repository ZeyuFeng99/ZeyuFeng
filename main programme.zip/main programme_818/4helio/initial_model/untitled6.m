close all; clear; clc

solar_radiation = [0 0 0  0  0 0 0 0  0  0 0 0 0  0  0 0 0 0  0  0 0.8 0.8 0.8   0.8  0.8 0.8 0.8 0.8 0.8   0.8 0.8 0.8 0.8 0.8 0.8 0.8  0.8 0.8  0.8 0.8 0.8 0.8 0.8  0.8 0.8 0.8 0.8 0.8 0.8 0.8 0.8  0.8 0.8  0.8 0.8 0.8 0.8 0.8   0.8 0.8 0.8 0.8 0.8 0.8 0.8  0.8 0.8  0.8 0.8 0.8 0.8 0.8  0.8 0.8 0.8 0.8 0.8 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 0 ];
n=0:0.25:24;
plot(n,solar_radiation);
xticks( [5 19.25] );
 xticklabels({'sunrise','sunset'});
 xlabel('Time of day');
 ylabel('Solar radiation(kW/m^2)');
 ylim([0 1])