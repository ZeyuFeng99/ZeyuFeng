close all; clear; clc

%% Solar position, parameter: Number of days from Jan. 1st, latitude, time spacing, ray_density
n=265; % Number of days from Jan. 1st 171 265 354
latitude= 51.3;  % latitude(degree)


%Declination Angle Calculation (cooper function)
dec = 23.45*sin(2*pi*(284+n)/365);
dec_rad= dec*pi/180;
W_rad = latitude*pi/180;
timespacing=0.01; number_timeslot = 24/ timespacing;
%% Heliostat  part, parameter:size of heliostat, length and width of mirror, position and radius of receiver, Number of mirrors per heliostat


%% Calculation part, parameter:Irradiance,  illuminated area
for i = 1:  number_timeslot +1
    %Local apparent time
    ts(i) =timespacing*(i-1)+0.0000001;

    % rotated angle, rotated matrix, solar ray direction and solar altitude
    [angle, M, solar_direct_unit,solar_altitude(i),solar_azimuth(i)] = sun_pos1(  ts(i) ,dec_rad,W_rad);
if (solar_altitude(i) < 0)
    solar_altitude(i)=0;
    solar_azimuth(i)=0;
end
end
plot(ts,solar_altitude,ts,solar_azimuth)
hold on
legend('Solar altitude','Solar azimuth')
xlabel('Local solar time(h)');
ylabel('Solar Position(degree)');
% title('Solar position in longest day 21/6');
 title('Solar position in equinox day 23/9');
% title('Solar position in shortest day 21/12');
hold off

clearvars  -except solar_azimuth