close all; clear; clc

start_angle =0 ; end_angle =5;
anglerange = end_angle-start_angle;
anglespacing=anglerange /8;
number_slot = anglerange/ anglespacing;
% Plot angle of tilt from 0-5
rotated_angle= start_angle:anglespacing:end_angle;% degree
rotated_angle= rotated_angle+0.00000001;% degree
E_total = zeros(1,9);

dayspacing=5; number_timeslot1 = floor(365/ dayspacing);
% Plot reference time of tilt from 4-20
n1 = 0:dayspacing:365;% Number of days from Jan. 1st
E_total  = zeros(1,number_timeslot1+1);

for i = 1:number_slot+1

    for ii = 1:number_timeslot1+1
        %% Solar position, parameter: Number of days from Jan. 1st, Local apparent time, latitude, ray_density

        %Local apparent time
        ray_density =60;
        latitude= 51.3;  % latitude(degree)
        %Declination Angle Calculation (cooper function)
        dec = 23.45*sin(2*pi*(284+n1(ii))/365);
        dec_rad= dec*pi/180;
        W_rad = latitude*pi/180;
        %% Heliostat  part, parameter:size of heliostat, length and width of mirror, position and radius of receiver, Irradiance
        % Parameters of mirror and receiver
        sizeof_heliostat =2;


        radius_sphere = 10;
        diamter_lateral = 0.5;
        deep = radius_sphere-sqrt (radius_sphere^2-(diamter_lateral/2)^2);
        % Position and size of circular receiver
        Pos_receiver = [0,  0 , 5];  radius_rec = 0.3;
        % receiver normal
        normal_re = [0, 0, 1]; normal_re_unit =unit(normal_re);
        [num_heliostats, pos_heliostat] = square_points(sizeof_heliostat);
        %Number of mirrors per heliostat
        num_mirrors_per_heli = 2;

        %% Calculation part, parameter:Irradiance,  illuminated area
        timespacing=1; number_timeslot = 24/ timespacing;
        % Solar position, parameter: Number of days from Jan. 1st, Local apparent time, irradiance
        %Local apparent time
        t = zeros(1,number_timeslot+1);
        Re_power = zeros(1,number_timeslot+1);
        cross_prod = zeros(num_heliostats,3);
        pos_mirror =  zeros(2*num_heliostats,3);
        direct_edge_unit_heli = zeros(num_heliostats,3);
        cross_prod_new = zeros(2*num_heliostats,3);
        direct_edge_unit =  zeros(2*num_heliostats,3);
        for iii = 1:number_timeslot+1
            t(iii) =timespacing*(iii-1);
            % rotated angle, rotated matrix, solar ray direction and solar altitude
            [angle, M, solar_direct_unit,solar_altitude] = Sun_pos(t(iii)+0.000000001,dec_rad,W_rad);

            if (solar_altitude < 0)
                fprintf('after sunset and before sunrise\n');

                Re_power(iii)=0;
            else
                %% determine normals of heliostats and draw
                % Irradiance
                irradiance =ray_density/2*(sizeof_heliostat);
                % illuminated area
                [num_flux, pos_flux] = square_points(irradiance);
                pos_flux1 = pos_flux*(sizeof_heliostat)/irradiance;
                for j=1:num_flux

                    if angle~= 0
                        pos_flux(j,:)=M*pos_flux1(j,:)';
                    else
                        pos_flux(j,:)= pos_flux1(j,:);
                    end
                end

                %%%Determine the normal vector
                normal_heli= zeros(size( pos_heliostat));
                normal= zeros(num_heliostats* num_mirrors_per_heli  ,3);
                for j=1:num_heliostats
                    %Desired reflectedrays
                    desired_reflected_ray = Pos_receiver -  pos_heliostat(j,:);
                    desired_reflected_ray_unit=unit(desired_reflected_ray);
                    %Angle between incident rays and desired reflected rays
                    [normal_heli(j,:),cross_prod(j,:)]= ...
                        normal_rotated(solar_direct_unit, desired_reflected_ray_unit);

                    pos_mirror(num_mirrors_per_heli*j-1,:)=pos_heliostat(j,:)+0.25*unit(cross_prod(j,:));
                    pos_mirror(num_mirrors_per_heli*j,:)=pos_heliostat(j,:)-0.25*unit(cross_prod(j,:));



                    direct_edge_unit_heli(j,:)= unit(cross(cross_prod(j,:),normal_heli(j,:))); % Find two orthonormal vectors which are orthogonal to v

                    M_mirror(:,:,1) = rotmatgen(unit(direct_edge_unit_heli(j,:)), rotated_angle(i)*pi/180);
                    M_mirror(:,:,2) = rotmatgen(unit(direct_edge_unit_heli(j,:)), -rotated_angle(i)*pi/180);

                    %mirror
                    for jj=1:num_mirrors_per_heli

                        normal(2*(j-1)+jj,:) = M_mirror(:,:,jj)*normal_heli(j,:)';
                        centre_mirror(num_mirrors_per_heli*(j-1)+jj,:) =  pos_mirror(num_mirrors_per_heli*(j-1)+jj,:) + radius_sphere*unit(normal(2*(j-1)+jj,:));






                    end
                    %         plot3([pos_mirror(num_mirrors_per_heli*j-1,1) pos_mirror(num_mirrors_per_heli*j,1)],[pos_mirror(num_mirrors_per_heli*j-1,2) pos_mirror(num_mirrors_per_heli*j,2)],[pos_mirror(num_mirrors_per_heli*j-1,3) pos_mirror(num_mirrors_per_heli*j,3)],  'color', 'black');
                end

                %% Reflected ray vector
                s0 = zeros(num_heliostats* num_mirrors_per_heli  ,1);
                intersection_point = zeros(size( pos_mirror));

                reflected_intersection_point =  [];
                distanceto_re=[];
                num_existray = 0;
                for j = 1:num_flux
                    flag = 0;
                    for jj = 1: num_heliostats* num_mirrors_per_heli

                        if (dot((centre_mirror(jj,:)-pos_flux(j,:)),solar_direct_unit)^2-dot((centre_mirror(jj,:)-pos_flux(j,:)),(centre_mirror(jj,:)-pos_flux(j,:)))+radius_sphere^2)>=0
                            %take negative value
                            s0(jj) = dot((centre_mirror(jj,:)-pos_flux(j,:)),solar_direct_unit)-sqrt(dot((centre_mirror(jj,:)-pos_flux(j,:)),solar_direct_unit)^2-dot((centre_mirror(jj,:)-pos_flux(j,:)),(centre_mirror(jj,:)-pos_flux(j,:)))+radius_sphere^2);


                            intersection_point(jj,:)= pos_flux(j,:)+ s0(jj)*solar_direct_unit;
                            if (whetherinsidesphere(diamter_lateral,radius_sphere,normal(jj,:), centre_mirror(jj,:),intersection_point(jj,:) )    )   && (flag ==0)
                                s0_eff = s0(jj);    flag = 1;   no_mirror = jj;
                            elseif (whetherinsidesphere(diamter_lateral,radius_sphere,normal(jj,:), centre_mirror(jj,:),intersection_point(jj,:) )    )  ...
                                    && (flag ==1)&&(s0(jj)>s0_eff)
                                s0_eff = s0(jj);    no_mirror = jj;
                            end
                        end
                    end
                    if flag
                        N = unit(centre_mirror(no_mirror, :)-intersection_point(no_mirror,:));

                        a2 = -solar_direct_unit - 2*dot(-solar_direct_unit,N)*N;
                        s0_ref= dot((Pos_receiver-intersection_point(no_mirror,:)),normal_re_unit)/dot(a2,normal_re_unit);
                        reflected_intersection_point(num_existray+1,:) = intersection_point(no_mirror,:)+s0_ref*a2;

                        distanceto_re(num_existray+1)  = norm(reflected_intersection_point(num_existray+1,:)-Pos_receiver);
                        num_existray  = num_existray +1;

                    end
                end



                %% effciency calculation

                index = 0;


                for j=1: num_existray
                    if distanceto_re(j)<=radius_rec
                        index=index+1;
                    end
                end

                % total 0.8kw/m^2
                Re_power(iii) = index*0.8/num_flux;
            end



            %     histogram(distanceto_re,max_radius);
            %     hold on
        end
        E_total (i,ii)= polyarea(t,Re_power);
    end
    E_total_year(i) = polyarea(n1,E_total(i,:) );
end
figure
plot(rotated_angle,E_total_year)
xlabel('Tilt angle');
ylabel('Received energy (kw·h/m^2)');
title('One year performance');


clearvars  -except  E_total_year E_total n1