close all; clear; clc
x=2:6;
x = 2*(x-1)+sqrt(2)
y=360*asin(1./x)/pi;
num= floor(360./y);

% scale =[1 3 5 7 9 11];
% numofheli=[4 8 12 20 24 32];
% start =sqrt(0.5^2+0.5^2);
% anglespacing=pi./numofheli;
% n0=1;
% for i=1:6
%     for j=1:numofheli(i)
%     mirror_pos(n0,:)=start*scale(i)*[cos(anglespacing(i)*(2*j-1)) sin(anglespacing(i)*(2*j-1)) 0];
%     n0=n0+1;
%     end
% end