function [num_heliostats,mirror_pos] = circle_point(scale )

numofheli=[4 8 12 20 24 32];
start =sqrt(0.1^2+0.1^2);
anglespacing=pi./numofheli;
n0=1;
for i=1:6
    for j=1:numofheli(i)
    mirror_pos(n0,:)=start*(scale*2*(i-1)/sqrt(2)+1)*[cos(anglespacing(i)*(2*j-1)) sin(anglespacing(i)*(2*j-1)) 0];
    n0=n0+1;
    end
end
num_heliostats=100;




end

