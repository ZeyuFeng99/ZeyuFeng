
start_spacing =1.05; end_spacing =1.75;
spacingrange = end_spacing-start_spacing;
spacingspacing=spacingrange /7;
number_slot = spacingrange/ spacingspacing;
spacing= start_spacing:spacingspacing:end_spacing;
dayspacing=1; number_timeslot1 = floor(365/ dayspacing);
% Plot reference time of tilt from 4-20
n1 = 0:dayspacing:365;% Number of days from Jan. 1st


figure
plot(spacing-1,E_total_year)
hold on
plot(spacing-1,E_total_year1)
plot(spacing-1,E_total_year2)


xlabel('Spacing (number of mirrors');
ylabel('Average Received energy (kw·h/m^2)');
legend('0.06','0.08','0.10')
title('One year performance');
clearvars  -except  E_total_year E_total E_total_year1 E_total1  E_total_year2 E_total2