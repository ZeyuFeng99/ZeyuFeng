close all; clear; clc
scale2 = 1:7;
angle2 =[1.52 1.49333 1.44 1.36 1.28 1.2 1.12];
% angle =[1.52 1.52 ];
cfun=fit(scale2',angle2','poly2');


%% Solar position, parameter: Number of days from Jan. 1st, Local apparent time, latitude, ray_density
n=265; % Number of days from Jan. 1st
%Local apparent time
scale3=2;

ts =12; ts = ts+0.00000001;
ray_density =100;

energy_scale=scale3^2;


latitude= 51.3;  % latitude(degree)
%Declination Angle Calculation (cooper function)
dec = 23.45*sin(2*pi*(284+n)/365);
dec_rad= dec*pi/180;
W_rad = latitude*pi/180;
%% Heliostat  part, parameter:size of heliostat, length and width of mirror, position and radius of receiver, Irradiance
% Parameters of mirror and receiver
scale = 5;
sizeof_heliostat =2*scale ;
side_area = 2;
length_m = 0.275/scale; width_m = 0.6557/scale;%maximum length and width
% Position and size of circular receiver
Pos_receiver = [0,  0 , 5/scale];  radius_rec = 0.06;
% receiver normal
normal_re = [0, 0, 1]; normal_re_unit =unit(normal_re);
[num_heliostats, pos_heliostat] = square_points(sizeof_heliostat);
pos_heliostat = scale3* pos_heliostat/scale;
%Number of mirrors per heliostat
num_mirrors_per_heli = 2;

%% Calculation part, parameter:Irradiance,  illuminated area
% rotated angle, rotated matrix, solar ray direction and solar altitude
[angle, M, solar_direct_unit,solar_altitude] = Sun_pos(ts,dec_rad,W_rad);

if (solar_altitude < 0)
    fprintf('after sunset and before sunrise\n');
    effciency_reflected=0;
    effciency_received=0;
else
    %% determine normals of heliostats and draw
    % Irradiance
    irradiance =ray_density/2*(side_area);
    % illuminated area
    [num_flux, pos_flux] = square_points(scale3 *irradiance);
    pos_flux1 = pos_flux*(side_area)/irradiance;
    for j=1:num_flux

        if angle~= 0
            pos_flux(j,:)=M*pos_flux1(j,:)';
        else
            pos_flux(j,:)= pos_flux1(j,:);
        end
    end

    %%%Determine the normal vector
    normal_heli= zeros(size( pos_heliostat));
    normal= zeros(num_heliostats* num_mirrors_per_heli  ,3);
    for j=1:num_heliostats
        %Desired reflectedrays
        desired_reflected_ray = Pos_receiver -  pos_heliostat(j,:);
        desired_reflected_ray_unit=unit(desired_reflected_ray);
        %Angle between incident rays and desired reflected rays
        [normal_heli(j,:),cross_prod(j,:)]= ...
            normal_rotated(solar_direct_unit, desired_reflected_ray_unit);

        pos_mirror(num_mirrors_per_heli*j-1,:)=pos_heliostat(j,:)+0.25/scale*unit(cross_prod(j,:));
        pos_mirror(num_mirrors_per_heli*j,:)=pos_heliostat(j,:)-0.25/scale*unit(cross_prod(j,:));

        scale1=norm(pos_heliostat(j,:))/norm([0.1 0.1]);
        cross_prod_unit_heli(j,:)= unit(cross_prod(j,:));
        direct_edge_unit_heli(j,:)= unit(cross(cross_prod(j,:),normal_heli(j,:))); % Find two orthonormal vectors which are orthogonal to v

        M_mirror(:,:,1) = rotmatgen(unit(direct_edge_unit_heli(j,:)), cfun(scale1)*pi/180);
        M_mirror(:,:,2) = rotmatgen(unit(direct_edge_unit_heli(j,:)), -cfun(scale1)*pi/180);

        %mirror
        for jj=1:num_mirrors_per_heli

            normal(2*(j-1)+jj,:) = M_mirror(:,:,jj)*normal_heli(j,:)';
            cross_prod_new(2*(j-1)+jj,:) = unit(cross(normal(2*(j-1)+jj,:) ,direct_edge_unit_heli(j,:)));



            direct_edge_unit(num_mirrors_per_heli*(j-1)+jj,:) = direct_edge_unit_heli(j, :);
            %             normal(num_mirrors_per_heli*(j-1)+jj,:) = normal_heli(j, :);
            normal_line= pos_mirror(num_mirrors_per_heli*(j-1)+jj,:) + 2*normal(2*(j-1)+jj,:);
            %             plot3([pos_mirror(num_mirrors_per_heli*(j-1)+jj,1) normal_line(1)], [pos_mirror(num_mirrors_per_heli*(j-1)+jj,2) normal_line(2)],[pos_mirror(num_mirrors_per_heli*(j-1)+jj,3) normal_line(3)],'color', 'cyan');
        end
       
    end



    %% Reflected ray vector
    s0 = zeros(num_heliostats* num_mirrors_per_heli  ,1);
    intersection_point = zeros(size( pos_mirror));

    num_existray = 0;
    num_existray2=0;
    for j = 1:num_flux
        flag = 0;
        for jj = 1: num_heliostats* num_mirrors_per_heli
            s0(jj)= dot((pos_mirror(jj,:)-pos_flux(j,:)),normal(jj, :))/dot(solar_direct_unit,normal(jj, :));
            intersection_point(jj,:)= pos_flux(j,:)+ s0(jj)*solar_direct_unit;
            if (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==0)
                s0_eff = s0(jj);    flag = 1;   no_mirror = jj;
            elseif (whetherinsidesquare(intersection_point(jj,:),pos_mirror(jj,:),length_m/2,width_m/2,cross_prod_new(jj,:),direct_edge_unit(jj,:) )) && (flag ==1)&&(s0(jj)>s0_eff)
                s0_eff = s0(jj);    no_mirror = jj;
            end
        end
        if flag
            a2 = -solar_direct_unit - 2*dot(-solar_direct_unit,normal(no_mirror, :))*normal(no_mirror, :);
            s0_ref= dot((Pos_receiver-intersection_point(no_mirror,:)),normal_re_unit)/dot(a2,normal_re_unit);
            reflected_intersection_point(num_existray+1,:) = intersection_point(no_mirror,:)+s0_ref*a2;

            distanceto_re(num_existray+1)  = norm(reflected_intersection_point(num_existray+1,:)-Pos_receiver);
            num_existray  = num_existray +1;
            if  norm((intersection_point(no_mirror,:)+s0_ref*a2)-Pos_receiver)<=radius_rec
                num_existray2  = num_existray2 +1;
            end
        end
    end

    figure;
    plot(reflected_intersection_point(:, 1), reflected_intersection_point(:, 2), '.','color','red'); hold on




    %% effciency calculation



    Maximum_aper = max(distanceto_re);

end
theta2=(0:2*pi/100:2*pi)';
circle1=radius_rec*cos(theta2);
circle2=radius_rec*sin(theta2);
plot(circle1,circle2,'black','linewidth',1);
hold off
axis equal
xlim([-0.1 0.1])
ylim([-0.1 0.1])
% figure
% histogram(distanceto_re,max_radius);
%
% xticks(max_radius);
% xlabel('Distance beteween intersection and receiver centre(m)');
% ylabel('Number of intersections');
% title('Receiver intersection distrubution');

clearvars  -except   scale1 angle11 pos_heliostat num_existray2 Maximum_aper