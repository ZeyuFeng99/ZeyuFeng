

function [angle,M] =  full_rotated(solar_direct_unit,desired_reflected_ray_unit)


    cross_prod= cross(solar_direct_unit, desired_reflected_ray_unit);


    angle = asin(norm(cross_prod));
    M= rotmatgen(unit(cross_prod), angle);



end