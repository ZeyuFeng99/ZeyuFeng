function parsave2(fname, x)
save(fname, 'x')
end
