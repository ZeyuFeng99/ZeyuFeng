function [num_mirrors, mirror_pos] = square_points(size)
    [x, y] = meshgrid(-(size-1)/2:(size-1)/2);
    num_mirrors = numel(x(:));
    mirror_x = reshape(x, [num_mirrors, 1]);
    mirror_y = reshape(y, [num_mirrors, 1]);
    mirror_z = zeros([num_mirrors, 1]);
    mirror_pos = [mirror_x, mirror_y, mirror_z];
end

