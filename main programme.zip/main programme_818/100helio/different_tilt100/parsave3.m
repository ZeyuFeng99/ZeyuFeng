function parsave3(fname, x)
save(fname, 'x')
end
